Please make 15 of these boards using standard thickness and board material etc.

Board Name: EqAmp
Version 1.6

Contact and shipping info:

Larry Cochrane
Webtronics
24 Garden St.
Redwood City, CA
94063

Phone: 650 365-7162
Email: lcochrane@webtronics.com
